"""
数据库模块 - 存储聊天历史
使用 SQLite（轻量级，不需要安装数据库服务器）
"""

import sqlite3
import os
from datetime import datetime

# 数据库文件放在项目根目录
DB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data",
    "chat_history.db"
)


def init_db():
    """
    初始化数据库，创建表（如果不存在）
    """
    # 确保目录存在
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 创建会话表
    cursor.execute("""
                   CREATE TABLE IF NOT EXISTS sessions
                   (
                       id
                       INTEGER
                       PRIMARY
                       KEY
                       AUTOINCREMENT,
                       session_id
                       TEXT
                       UNIQUE
                       NOT
                       NULL,
                       title
                       TEXT,
                       created_at
                       TIMESTAMP
                       DEFAULT
                       CURRENT_TIMESTAMP,
                       updated_at
                       TIMESTAMP
                       DEFAULT
                       CURRENT_TIMESTAMP
                   )
                   """)

    # 创建消息表
    cursor.execute("""
                   CREATE TABLE IF NOT EXISTS messages
                   (
                       id
                       INTEGER
                       PRIMARY
                       KEY
                       AUTOINCREMENT,
                       session_id
                       TEXT
                       NOT
                       NULL,
                       role
                       TEXT
                       NOT
                       NULL,
                       content
                       TEXT
                       NOT
                       NULL,
                       sources
                       TEXT,
                       created_at
                       TIMESTAMP
                       DEFAULT
                       CURRENT_TIMESTAMP,
                       FOREIGN
                       KEY
                   (
                       session_id
                   ) REFERENCES sessions
                   (
                       session_id
                   )
                       )
                   """)

    conn.commit()
    conn.close()
    print(f"✅ 数据库初始化完成: {DB_PATH}")


def save_message(session_id, role, content, sources=None):
    """
    保存一条消息

    参数:
        session_id: 会话 ID
        role: 角色（user/assistant）
        content: 消息内容
        sources: 参考来源（JSON 字符串）
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 确保会话存在
    cursor.execute(
        "INSERT OR IGNORE INTO sessions (session_id) VALUES (?)",
        (session_id,)
    )

    # 保存消息
    cursor.execute(
        "INSERT INTO messages (session_id, role, content, sources) VALUES (?, ?, ?, ?)",
        (session_id, role, content, sources)
    )

    # 更新时间戳
    cursor.execute(
        "UPDATE sessions SET updated_at = CURRENT_TIMESTAMP WHERE session_id = ?",
        (session_id,)
    )

    conn.commit()
    conn.close()


def get_session_history(session_id, limit=50):
    """
    获取会话的历史消息

    返回:
        list: 消息列表，每个元素是 (role, content, sources)
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT role, content, sources
        FROM messages
        WHERE session_id = ?
        ORDER BY created_at ASC LIMIT ?
        """,
        (session_id, limit)
    )

    results = cursor.fetchall()
    conn.close()

    return results


def list_sessions():
    """
    获取所有会话列表（按更新时间倒序）

    返回:
        list: 会话列表，每个元素是 dict
    """
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT session_id, title, created_at, updated_at
        FROM sessions
        ORDER BY updated_at DESC LIMIT 50
        """
    )

    results = cursor.fetchall()
    conn.close()

    sessions = []
    for row in results:
        sessions.append({
            "session_id": row[0],
            "title": row[1] or "新对话",
            "created_at": row[2],
            "updated_at": row[3]
        })

    return sessions


def update_session_title(session_id, title):
    """更新会话标题"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE sessions SET title = ? WHERE session_id = ?",
        (title, session_id)
    )
    conn.commit()
    conn.close()


def delete_session(session_id):
    """删除会话"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
    cursor.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()


# ==================== 初始化 ====================
# 模块加载时自动初始化数据库
init_db()