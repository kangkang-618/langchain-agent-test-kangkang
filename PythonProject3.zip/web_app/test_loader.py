"""
测试 document_loader.py
"""

import os
import sys

# 把上级目录加到路径，这样能导入 config
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from document_loader import DocumentLoader
import config


def test_1_create_loader():
    """测试1：创建加载器"""
    print("=" * 50)
    print("测试1：创建 DocumentLoader")
    print("=" * 50)

    loader = DocumentLoader()
    print(f"✅ 加载器创建成功！")
    print(f"   支持的类型: {loader.supported_types}")
    return loader


def test_2_check_supported_types(loader):
    """测试2：检查支持的文件类型"""
    print("\n" + "=" * 50)
    print("测试2：检查支持的文件类型")
    print("=" * 50)

    expected_types = [".pdf", ".docx", ".doc", ".txt", ".md"]

    for ext in expected_types:
        if ext in loader.supported_types:
            print(f"✅ 支持: {ext}")
        else:
            print(f"❌ 不支持: {ext}")


def test_3_unsupported_file(loader):
    """测试3：处理不支持的文件类型"""
    print("\n" + "=" * 50)
    print("测试3：处理不支持的文件类型")
    print("=" * 50)

    try:
        # 故意用一个不支持的格式
        loader.get_loader("test.xlsx")
        print("❌ 应该报错但没报！")
    except ValueError as e:
        print(f"✅ 正确报错: {str(e)[:50]}...")


def test_4_load_real_file(loader):
    """测试4：加载真实文件"""
    print("\n" + "=" * 50)
    print("测试4：加载真实文件")
    print("=" * 50)

    # 检查知识库目录里有没有文件
    kb_path = config.KNOWLEDGE_BASE_PATH

    if not os.path.exists(kb_path):
        print(f"📁 知识库目录不存在，跳过测试")
        return

    files = [f for f in os.listdir(kb_path) if os.path.isfile(os.path.join(kb_path, f))]

    if not files:
        print(f"📁 知识库里没有文件，跳过测试")
        print(f"   提示：往 knowledge_base 文件夹放一个 .txt 或 .md 文件")
        return

    # 找第一个能处理的文件
    for filename in files:
        file_path = os.path.join(kb_path, filename)
        ext = os.path.splitext(filename)[1].lower()

        if ext in loader.supported_types:
            print(f"📄 找到文件: {filename}")

            try:
                docs = loader.load(file_path)
                print(f"✅ 加载成功！共 {len(docs)} 个文档块")
                print(f"   内容预览: {docs[0].page_content[:100]}...")
                return
            except Exception as e:
                print(f"❌ 加载失败: {e}")


def main():
    print("\n🧪 开始测试 document_loader.py\n")

    # 测试1：创建加载器
    loader = test_1_create_loader()

    # 测试2：检查支持类型
    test_2_check_supported_types(loader)

    # 测试3：处理不支持的文件
    test_3_unsupported_file(loader)

    # 测试4：加载真实文件
    test_4_load_real_file(loader)

    print("\n" + "=" * 50)
    print("✅ 所有测试完成！")
    print("=" * 50)


if __name__ == "__main__":
    main()