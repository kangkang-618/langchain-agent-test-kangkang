"""
测试 API 接口
"""

import requests
import json

BASE_URL = "http://localhost:5000/api"


def test_health():
    """测试健康检查"""
    print("=" * 50)
    print("测试：健康检查")
    print("=" * 50)
    resp = requests.get(f"{BASE_URL}/health")
    print(f"状态码: {resp.status_code}")
    print(f"响应: {resp.json()}")


def test_chat():
    """测试问答"""
    print("\n" + "=" * 50)
    print("测试：问答接口")
    print("=" * 50)

    data = {
        "question": "RAG是什么？",
        "session_id": "test_api"
    }

    resp = requests.post(f"{BASE_URL}/chat", json=data)
    print(f"状态码: {resp.status_code}")

    result = resp.json()
    print(f"\n回答:\n{result.get('answer', '')[:200]}...")
    print(f"\n来源数量: {len(result.get('sources', []))}")


def test_sessions():
    """测试会话列表"""
    print("\n" + "=" * 50)
    print("测试：会话列表")
    print("=" * 50)

    resp = requests.get(f"{BASE_URL}/sessions")
    print(f"状态码: {resp.status_code}")
    print(f"响应: {resp.json()}")


if __name__ == "__main__":
    test_health()
    test_chat()
    test_sessions()
    print("\n✅ API 测试完成！")