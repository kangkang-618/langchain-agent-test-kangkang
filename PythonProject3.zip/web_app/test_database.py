"""测试数据库"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import database

# 测试1：保存消息
print("=" * 50)
print("测试1：保存消息")
print("=" * 50)

session_id = "test_session_001"
database.save_message(session_id, "user", "你好")
database.save_message(session_id, "assistant", "你好！有什么可以帮助你的？")
print("✅ 保存成功")

# 测试2：读取历史
print("\n" + "=" * 50)
print("测试2：读取历史")
print("=" * 50)

history = database.get_session_history(session_id)
for role, content, sources in history:
    print(f"  [{role}] {content}")

# 测试3：会话列表
print("\n" + "=" * 50)
print("测试3：会话列表")
print("=" * 50)

sessions = database.list_sessions()
for s in sessions:
    print(f"  - {s['session_id']}: {s['title']}")

# 清理测试数据
database.delete_session(session_id)
print("\n✅ 测试完成！")