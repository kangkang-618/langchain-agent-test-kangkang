"""
测试 qa_chain.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from retriever import Retriever
from qa_chain import QAChain


def test_1_create_qa_chain():
    """测试1：创建 QAChain"""
    print("=" * 50)
    print("测试1：创建 QAChain")
    print("=" * 50)

    try:
        retriever = Retriever()
        qa = QAChain(retriever)
        print("✅ QAChain 创建成功！")
        return qa
    except Exception as e:
        print(f"❌ 创建失败: {e}")
        return None


def test_2_basic_qa(qa):
    """测试2：基础问答"""
    print("\n" + "=" * 50)
    print("测试2：基础问答")
    print("=" * 50)

    if qa is None:
        return

    questions = [
        "RAG是什么？",
        "RAG有哪些组成部分？",
    ]

    for question in questions:
        print(f"\n❓ 问题: {question}")
        print("🤔 AI 思考中...")

        try:
            answer, sources = qa.answer(question)
            print(f"\n✅ 回答:\n{answer}")
            print(f"\n📖 参考来源: {len(sources)} 条")
            if sources:
                for i, s in enumerate(sources, 1):
                    print(f"  [{i}] {s['source']}")
        except Exception as e:
            print(f"❌ 回答失败: {e}")


def test_3_multi_turn(qa):
    """测试3：多轮对话"""
    print("\n" + "=" * 50)
    print("测试3：多轮对话")
    print("=" * 50)

    if qa is None:
        return

    # 检查知识库是否有文档
    docs = qa.retriever.list_documents()
    if not docs:
        print("📭 知识库为空，跳过多轮对话测试")
        return

    # 第一轮
    print("\n🌱 第一轮:")
    question1 = "RAG是什么？"
    print(f"❓ 你: {question1}")
    answer1, _ = qa.answer(question1)
    print(f"🤖 AI: {answer1[:100]}...")

    # 构建历史
    history = [
        ("user", question1),
        ("assistant", answer1)
    ]

    # 第二轮（带历史）
    print("\n🌱 第二轮（带历史）:")
    question2 = "能举个例子吗？"
    print(f"❓ 你: {question2}")
    print("🤔 AI 思考中（考虑上一轮对话）...")

    answer2, _ = qa.answer(question2, history=history)
    print(f"🤖 AI: {answer2[:100]}...")


def test_4_no_context(qa):
    """测试4：无文档时的回答"""
    print("\n" + "=" * 50)
    print("测试4：无文档时的回答")
    print("=" * 50)

    if qa is None:
        return

    # 清空知识库
    print("🗑️ 清空知识库...")
    qa.retriever.clear()

    question = "Python 怎么定义函数？"
    print(f"\n❓ 问题（无文档）: {question}")
    print("🤔 AI 思考中...")

    try:
        answer, sources = qa.answer(question)
        print(f"\n✅ 回答:\n{answer}")
        print(f"\n📖 参考来源: {len(sources)} 条（无来源，纯靠 AI 知识）")
    except Exception as e:
        print(f"❌ 回答失败: {e}")


def main():
    print("\n🧪 开始测试 qa_chain.py\n")

    # 测试1：创建
    qa = test_1_create_qa_chain()

    # 测试2：基础问答
    test_2_basic_qa(qa)

    # 测试3：多轮对话
    test_3_multi_turn(qa)

    # 测试4：无文档
    test_4_no_context(qa)

    print("\n" + "=" * 50)
    print("✅ 所有测试完成！")
    print("=" * 50)


if __name__ == "__main__":
    main()