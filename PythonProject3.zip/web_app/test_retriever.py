"""
测试 retriever.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from retriever import Retriever


def test_1_create_retriever():
    """测试1：创建检索器"""
    print("=" * 50)
    print("测试1：创建 Retriever")
    print("=" * 50)

    try:
        retriever = Retriever()
        print("✅ Retriever 创建成功！")
        return retriever
    except Exception as e:
        print(f"❌ 创建失败: {e}")
        return None


def test_2_list_documents(retriever):
    """测试2：列出已有文档"""
    print("\n" + "=" * 50)
    print("测试2：列出已有文档")
    print("=" * 50)

    docs = retriever.list_documents()
    print(f"📚 知识库已有文档: {docs}")
    return docs


def test_3_basic_search(retriever, has_docs):
    """测试3：基础检索"""
    print("\n" + "=" * 50)
    print("测试3：基础检索")
    print("=" * 50)

    if not has_docs:
        print("📭 知识库为空，跳过检索测试")
        return

    queries = [
        "RAG是什么",
        "什么是检索增强",
        "向量数据库",
    ]

    for query in queries:
        print(f"\n🔍 搜索: {query}")
        results = retriever.retrieve(query, top_k=3)

        if not results:
            print("   ❌ 没有找到结果")
            continue

        print(f"   ✅ 找到 {len(results)} 条:")
        for i, r in enumerate(results, 1):
            print(f"   [{i}] {r['source']}")
            print(f"       相似度: {r['score']:.4f}")
            print(f"       内容: {r['content'][:60]}...")


def test_4_hybrid_search(retriever, has_docs):
    """测试4：混合检索"""
    print("\n" + "=" * 50)
    print("测试4：混合检索")
    print("=" * 50)

    if not has_docs:
        print("📭 知识库为空，跳过混合检索测试")
        return

    query = "RAG 技术"
    print(f"\n🔍 混合搜索: {query}")

    results = retriever.hybrid_retrieve(query, top_k=3)

    if not results:
        print("   ❌ 没有找到结果")
        return

    print(f"   ✅ 找到 {len(results)} 条:")
    for i, r in enumerate(results, 1):
        match_type = r.get("match_type", "unknown")
        print(f"   [{i}] {r['source']} [{match_type}]")
        print(f"       内容: {r['content'][:60]}...")


def test_5_keyword_match(retriever, has_docs):
    """测试5：关键词匹配"""
    print("\n" + "=" * 50)
    print("测试5：关键词匹配")
    print("=" * 50)

    if not has_docs:
        print("📭 知识库为空，跳过关键词匹配测试")
        return

    # 先获取一些候选文档
    candidates = retriever.retrieve("RAG", top_k=5)

    if not candidates:
        print("📭 没有候选文档")
        return

    # 测试关键词匹配
    query = "RAG 检索"
    print(f"🔍 关键词匹配测试: {query}")

    matched = retriever._keyword_match(query, candidates)

    print(f"   匹配结果: {len(matched)} 条")
    for i, (count, doc) in enumerate(zip([m for m in matched], matched), 1):
        print(f"   [{i}] {doc['content'][:50]}...")


def main():
    print("\n🧪 开始测试 retriever.py\n")

    # 测试1：创建
    retriever = test_1_create_retriever()

    # 测试2：列出文档
    docs = test_2_list_documents(retriever)
    has_docs = len(docs) > 0

    # 测试3：基础检索
    test_3_basic_search(retriever, has_docs)

    # 测试4：混合检索
    test_4_hybrid_search(retriever, has_docs)

    # 测试5：关键词匹配
    test_5_keyword_match(retriever, has_docs)

    print("\n" + "=" * 50)
    print("✅ 所有测试完成！")
    print("=" * 50)


if __name__ == "__main__":
    main()