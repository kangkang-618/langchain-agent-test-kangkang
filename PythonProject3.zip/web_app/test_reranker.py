"""测试重排序"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from reranker import Reranker

print("\n🧪 测试 Reranker\n")

reranker = Reranker()

docs = [
    {"content": "Python 是一种编程语言", "source": "doc1.txt", "score": 0.5},
    {"content": "人工智能 AI 很重要", "source": "doc2.txt", "score": 0.6},
    {"content": "RAG 是检索增强生成技术", "source": "doc3.txt", "score": 0.4},
    {"content": "机器学习是 AI 的子领域", "source": "doc4.txt", "score": 0.3},
    {"content": "Java 是一种编程语言", "source": "doc5.txt", "score": 0.7},
]

query = "什么是 RAG？"
print(f"问题: {query}")
print(f"原始结果: {len(docs)} 个文档\n")

reranked = reranker.rerank(query, docs, top_k=3)

print(f"重排序后: {len(reranked)} 个最相关文档\n")
for i, doc in enumerate(reranked, 1):
    print(f"  [{i}] {doc['source']}")
    print(f"      内容: {doc['content']}")

print("\n✅ 测试完成！")