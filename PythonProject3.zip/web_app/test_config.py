"""
测试 config.py 配置是否正确
"""

import config

# 测试1：打印配置
print("=" * 50)
print("测试1：检查配置路径")
print("=" * 50)
print(f"项目根目录: {config.PROJECT_ROOT}")
print(f"向量库路径: {config.CHROMA_PATH}")
print(f"文档路径: {config.KNOWLEDGE_BASE_PATH}")

# 测试2：检查 API Key 是否已配置
print("\n" + "=" * 50)
print("测试2：检查 API Key")
print("=" * 50)
print(f"DeepSeek Key: {config.DEEPSEEK_API_KEY[:10]}..." if config.DEEPSEEK_API_KEY != "sk-your-deepseek-api-key" else "⚠️  DeepSeek Key 还没配置！")
print(f"Embedding Key: {config.EMBEDDING_API_KEY[:10]}..." if config.EMBEDDING_API_KEY != "your-siliconflow-api-key" else "⚠️  Embedding Key 还没配置！")

# 测试3：检查目录是否存在
print("\n" + "=" * 50)
print("测试3：检查目录")
print("=" * 50)
import os
for path_name, path_value in [
    ("向量库目录", config.CHROMA_PATH),
    ("文档目录", config.KNOWLEDGE_BASE_PATH),
]:
    if os.path.exists(path_value):
        print(f"✅ {path_name}: 已存在")
    else:
        print(f"📁 {path_name}: 不存在（运行时会自动创建）")

print("\n✅ config.py 测试通过！")