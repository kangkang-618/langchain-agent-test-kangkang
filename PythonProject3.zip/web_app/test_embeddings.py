"""
测试 embeddings.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from document_loader import DocumentLoader
from embeddings import EmbeddingManager
import config


def test_1_create_manager():
    """测试1：创建 EmbeddingManager"""
    print("=" * 50)
    print("测试1：创建 EmbeddingManager")
    print("=" * 50)

    try:
        manager = EmbeddingManager()
        print("✅ EmbeddingManager 创建成功！")
        return manager
    except Exception as e:
        print(f"❌ 创建失败: {e}")
        return None


def test_2_list_documents(manager):
    """测试2：列出已有文档"""
    print("\n" + "=" * 50)
    print("测试2：列出已有文档")
    print("=" * 50)

    if manager is None:
        return

    docs = manager.list_documents()
    print(f"📚 已有文档: {docs}")


def test_3_add_document(manager):
    """测试3：添加文档到向量库"""
    print("\n" + "=" * 50)
    print("测试3：添加文档到向量库")
    print("=" * 50)

    if manager is None:
        return

    # 检查知识库目录
    kb_path = config.KNOWLEDGE_BASE_PATH
    if not os.path.exists(kb_path):
        print("📁 知识库目录不存在")
        return

    files = [f for f in os.listdir(kb_path)
             if os.path.isfile(os.path.join(kb_path, f))]

    if not files:
        print("📁 知识库里没有文件")
        return

    # 加载第一个文件
    loader = DocumentLoader()
    filename = files[0]
    file_path = os.path.join(kb_path, filename)

    print(f"📄 加载文件: {filename}")
    docs = loader.load(file_path)
    print(f"   文档块数: {len(docs)}")

    # 添加到向量库
    manager.add_documents(docs, filename)
    print(f"✅ 添加成功！")


def test_4_search(manager):
    """测试4：搜索功能"""
    print("\n" + "=" * 50)
    print("测试4：搜索功能")
    print("=" * 50)

    if manager is None:
        return

    # 检查有没有数据
    docs = manager.list_documents()
    if not docs:
        print("📭 知识库为空，先添加文档再测试搜索")
        return

    # 搜索
    query = "RAG是什么"
    print(f"🔍 搜索: {query}")

    results = manager.search(query, top_k=3)

    if not results:
        print("❌ 没有找到结果")
        return

    print(f"✅ 找到 {len(results)} 条相关内容:\n")

    for i, doc in enumerate(results, 1):
        print(f"--- 结果 {i} ---")
        print(f"来源: {doc['source']}")
        print(f"相似度分数: {doc['score']:.4f}")
        print(f"内容: {doc['content'][:80]}...")
        print()


def main():
    print("\n🧪 开始测试 embeddings.py\n")

    # 测试1：创建
    manager = test_1_create_manager()

    # 测试2：列出文档
    test_2_list_documents(manager)

    # 测试3：添加文档
    test_3_add_document(manager)

    # 测试4：搜索
    test_4_search(manager)

    print("\n" + "=" * 50)
    print("✅ 所有测试完成！")
    print("=" * 50)


if __name__ == "__main__":
    main()